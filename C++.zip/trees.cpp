#include <iostream>
#include <vector>
#include <string.h>
#include<unordered_map>
#include<sstream>
using namespace std;

struct TreeNode{
    int val;
    TreeNode* left;
    TreeNode* right;
    TreeNode(int x) : val(x), left(NULL), right(NULL){}
};

class Solution{
public:
    static bool issametrees(TreeNode* root1, TreeNode* root2){
        if(!root1 && !root2) return true;
        if(!root1 || !root2) return false;
        return (root1->val==root2->val) && issametrees(root1->left, root2->right) 
        && issametrees(root1->right, root2->left);
    }
};

int main(){
    Solution a;
    TreeNode* tn_0_0 = new TreeNode(0);
    TreeNode* tn_1_0 = new TreeNode(1);
    TreeNode* tn_1_1 = new TreeNode(1);
    TreeNode* tn_2_0 = new TreeNode(2);
    TreeNode* tn_2_1 = new TreeNode(3);
    TreeNode* tn_2_2 = new TreeNode(3);
    TreeNode* tn_2_3 = new TreeNode(2);
    tn_0_0->left = tn_1_0;
    tn_0_0->right = tn_1_1;
    tn_1_0->left = tn_2_0;
    tn_1_0->right = tn_2_1;
    tn_1_1->left = tn_2_2;
    tn_1_1->right = tn_2_3;
    bool res = Solution::issametrees(tn_0_0, tn_0_0);
    return 0;
}
