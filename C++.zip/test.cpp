#include <iostream>
#include <vector>
#include <string.h>
#include<unordered_map>
#include<unordered_set>
using namespace std;


class Solution{
public:
    bool compare(string& s){
       unordered_set<int> set;
       unordered_map<char, int> map;
       int n = s.size();
       for(int i=0;i<n;i++){
           map[s[i]]++;
       }
       int res = 0;
       for(auto& m:map){
          res += (m.second%2);
       }
       return res<=1;

    }
};

string s = "abbacc";

int main()
{ 
   Solution a;
   bool ans = a.compare(s);
   cout << boolalpha << ans << endl;
   return 0;

}