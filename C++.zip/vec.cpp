#include <vector>
#include <algorithm>
#include <iostream>
#include <math.h>
using namespace std;

class solution{
public:
    void rev(vector<int>& nums, int n){
        int i=0;
        n = (1<<n);
        int m = nums.size()/n;
        while(m--){
          reverse(nums.begin() + i , nums.begin()+i+n);
          i += n;
        }
    }
    
    int mergesort(vector<int>& nums, vector<int>& cop, int l, int r){
        if(l>=r) return 0;
        int mid = l + (r-l)/2;
        int count = mergesort(nums, cop, l, mid) + mergesort(nums, cop, mid+1, r);
        int i=l, pos=l, j=mid+1;
        while(i<=mid && j<=r){
            if(nums[i]<=nums[j]){
                cop[pos]=nums[i];
                count += j-mid-1;
                i++;
            }
            else{
                cop[pos]=nums[j];
                j++;
            }
            pos++;
        }
        for(int k=i;k<=mid;k++){
            cop[pos++]=nums[k];
            count += j-mid-1;
        }
        for(int k=j;k<=r;k++){
            cop[pos++]=nums[k];
        }
        copy(cop.begin()+l, cop.begin()+r+1, nums.begin()+l);
        return count;
    }
};

int main(){
    solution a;
    int n;
    cin>>n;
    n = (1<<n);
    vector<int> nums(n,0);
    for(int i=0;i<n;i++){
        cin>>nums[i];
    }
    int m;
    cin>>m;
    vector<int> cur(m,0);
    for(int i=0;i<m;i++){
        cin>>cur[i];
    }
    for(int i=0;i<m;i++){
        a.rev(nums, cur[i]);
        vector<int> cop(n,0);
        vector<int> nums2 = nums;
        int ans = a.mergesort(nums2, cop, 0, n-1);
        cout<<ans<<endl;
    }
    return 0;
}