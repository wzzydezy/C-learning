#include<stdio.h>
#include<iostream>
using namespace std;

template <typename T>
class Shared_ptr{
private:
  size_t* m_count;
  T* m_ptr;

public:
  //构造函数
  Shared_ptr():m_ptr(nullptr), m_count(new size_t){}
  Shared_ptr(T* ptr):m_ptr(ptr), m_count(new size_t){
      cout<<"空间申请:"<<ptr<<endl;
      *m_count = 1;
  }
  ~Shared_ptr(){
      --(*m_count);
      if(*m_count==0){
          cout<<"空间释放："<<m_ptr<<endl;
          delete m_ptr;
          delete m_count;
          m_ptr = nullptr;
          m_count = nullptr;
      }
  }
  //拷贝构造函数
  Shared_ptr(const Shared_ptr& ptr){
      //cout<<"拷贝构造:"<<endl;
      m_count = ptr.m_count;
      m_ptr = ptr.m_ptr;
      ++(*m_count);
  }

  void operator= (const Shared_ptr& ptr){
      Shared_ptr(move(ptr));
  }

  T& operator*(){
      return *m_ptr;
  }

  T* operator->(){
      return m_ptr;
  }
};

int main(){
    Shared_ptr<int> p1(new int);
    Shared_ptr<int> p2 = p1;
    return 0;
}



