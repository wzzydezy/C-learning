#include <iostream>
#include <vector>
#include <string.h>
#include<unordered_map>
#include<sstream>
#include<queue>
#include<stack>
using namespace std;

int main(){
    string s = "GET /562f25980001b1b106000338.jpg HTTP/1.1";
    const char* text = &s[0];
    char* m_url = strpbrk(text, " \t");
    
}