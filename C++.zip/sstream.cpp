#include <iostream>
#include <vector>
#include <string.h>
#include<unordered_map>
#include<sstream>
#include<algorithm>
using namespace std;

int main(){
    vector<int> a ={1,2,3,4};
    reverse(a.begin(), a.end());
}