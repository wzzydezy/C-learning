#include <iostream>
#include <vector>
#include <string.h>
#include <unordered_map>
#include <sstream>
#include <queue>
#include <stack>
#include <math.h>
#include <stdlib.h>
#include <algorithm>
#include <limits.h>
#include <list>
#include <stdlib.h>
using namespace std;

int main(){
    unordered_map<int, int> z;
    pair<int, int> p1(1,2);
    z.insert(p1);
    z[3]=4;
    return 0;
}
